from http.server import BaseHTTPRequestHandler, HTTPServer

HTML = """<!DOCTYPE html>
<html lang="ru">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MedPrice РК</title>
    <style>
      :root {
        --bg: #f4f7fc;
        --surface: #ffffff;
        --surface-2: #edf4ff;
        --text: #1e293b;
        --muted: #64748b;
        --primary: #2563eb;
        --success: #10b981;
        --warning: #f59e0b;
        --border: #e2e8f0;
        --shadow: 0 10px 30px rgba(0, 0, 0, 0.04);
      }
      * { box-sizing: border-box; }
      body { margin: 0; font-family: -apple-system, Arial, sans-serif; color: var(--text); background: var(--bg); }
      .container { max-width: 1300px; margin: 0 auto; padding: 24px; }
      
      header { display: flex; justify-content: space-between; align-items: center; background: white; padding: 16px 24px; border-radius: 16px; box-shadow: var(--shadow); margin-bottom: 24px; }
      .logo { font-size: 1.5rem; font-weight: 800; color: var(--primary); text-decoration: none; }
      
      .controls-right { display: flex; gap: 15px; align-items: center; }
      select { padding: 10px 14px; border-radius: 8px; border: 1px solid var(--border); font-size: 0.95rem; outline: none; background: var(--surface-2); color: var(--primary); font-weight: 600; cursor: pointer; }
      
      .lang-switch { display: flex; gap: 5px; background: #e2e8f0; padding: 4px; border-radius: 8px; }
      .lang-btn { border: none; background: transparent; padding: 6px 12px; font-weight: bold; border-radius: 6px; cursor: pointer; }
      .lang-btn.active { background: white; color: var(--primary); box-shadow: 0 2px 8px rgba(0,0,0,0.1); }

      .search-container { display: flex; gap: 12px; margin-bottom: 24px; background: white; padding: 12px; border-radius: 12px; box-shadow: var(--shadow); }
      .search-container input { flex: 1; border: 1px solid var(--border); padding: 12px; border-radius: 8px; font-size: 1rem; outline: none; }
      .search-container button { background: var(--primary); color: white; border: none; padding: 12px 24px; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer; }
      
      .layout { display: grid; grid-template-columns: 1fr 420px; gap: 24px; }
      
      .card { background: white; border-radius: 12px; padding: 18px; margin-bottom: 16px; border: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; box-shadow: var(--shadow); transition: 0.2s; }
      .card:hover { border-color: var(--primary); transform: translateY(-2px); }
      .clickable-area { flex: 1; cursor: pointer; }
      .card h4 { margin: 0 0 4px 0; font-size: 1.25rem; color: #0f172a; text-decoration: underline; text-decoration-color: #cbd5e1; }
      .card h4:hover { color: var(--primary); text-decoration-color: var(--primary); }
      
      /* МЕСТОНАХОЖДЕНИЕ НА КАРТОЧКЕ */
      .card .location-banner { font-size: 0.88rem; color: #475569; margin: 6px 0; background: #f1f5f9; padding: 6px 10px; border-radius: 6px; width: fit-content; }
      
      .badge-container { display: flex; gap: 6px; margin-bottom: 8px; }
      .badge-cheap { background: #dcfce7; color: #15803d; font-size: 0.75rem; font-weight: 800; padding: 4px 8px; border-radius: 6px; }
      .badge-best { background: #fef3c7; color: #b45309; font-size: 0.75rem; font-weight: 800; padding: 4px 8px; border-radius: 6px; }
      
      .rating-stars { color: var(--warning); font-weight: 700; font-size: 0.9rem; }
      .price { font-size: 1.7rem; font-weight: 800; color: var(--success); text-align: right; }
      .btn-compare { background: var(--surface-2); color: var(--primary); border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 0.85rem; margin-top: 10px; }

      /* МОДАЛКА */
      .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: center; z-index: 1000; }
      .modal-content { background: white; padding: 30px; border-radius: 16px; max-width: 600px; width: 90%; box-shadow: var(--shadow); position: relative; }
      .close-modal { position: absolute; top: 15px; right: 20px; font-size: 1.8rem; cursor: pointer; color: var(--muted); }
      .staff-box { background: #eff6ff; border-left: 4px solid var(--primary); padding: 12px 16px; border-radius: 0 8px 8px 0; margin: 15px 0; }
      
      .sidebar { background: white; padding: 20px; border-radius: 12px; border: 1px solid var(--border); height: fit-content; position: sticky; top: 24px; box-shadow: var(--shadow); }
      .compare-item { padding: 12px 0; border-bottom: 1px dashed var(--border); }
      .remove-btn { color: #ef4444; border: none; background: none; cursor: pointer; font-weight: bold; font-size: 1.2rem; float: right; }
    </style>
  </head>
  <body>
    <div class="container">
      <header>
        <a href="#" class="logo" id="lbl-logo">MedPrice РК 🇰🇿</a>
        <div class="controls-right">
          <select id="city-select">
            <option value="all" id="opt-all-cities">Все города</option>
            <option value="Алматы">Алматы</option>
            <option value="Астана">Астана</option>
            <option value="Караганда">Караганда</option>
            <option value="Шымкент">Шымкент</option>
            <option value="Актобе">Актобе</option>
            <option value="Усть-Каменогорск">Усть-Каменогорск</option>
            <option value="Павлодар">Павлодар</option>
          </select>
          <div class="lang-switch">
            <button class="lang-btn active" onclick="setLanguage('ru')">RU</button>
            <button class="lang-btn" onclick="setLanguage('kk')">KK</button>
            <button class="lang-btn" onclick="setLanguage('en')">EN</button>
          </div>
        </div>
      </header>

      <div class="search-container">
        <input type="text" id="search-input" placeholder="Поиск услуг..." />
        <button id="search-btn">Найти</button>
      </div>

      <div class="layout">
        <div id="grid-content"></div>
        <div class="sidebar">
          <h3 id="lbl-sidebar-title">Выбранные предложения 🛒</h3>
          <div id="compare-list"></div>
          <div style="margin-top:20px; padding-top:12px; border-top: 2px solid var(--border)">
            <strong id="lbl-total">Итого чек:</strong>
            <span id="total-price" style="float:right; color:var(--success); font-weight:800; font-size:1.4rem;">0 ₸</span>
          </div>
        </div>
      </div>
    </div>

    <div id="service-modal" class="modal" onclick="closeModal(event)">
      <div class="modal-content" onclick="event.stopPropagation()">
        <span class="close-modal" onclick="document.getElementById('service-modal').style.display='none'">&times;</span>
        <h2 id="modal-title" style="color:var(--primary); margin-top:0; margin-bottom: 5px;"></h2>
        <div id="modal-clinic-brand" style="font-weight: 700; color: var(--muted); margin-bottom: 15px;"></div>
        
        <div class="staff-box">
          <h4 style="margin: 0 0 6px 0; color: var(--primary);" id="lbl-staff-title">📞 Контакты сотрудников для записи:</h4>
          <div id="modal-staff-phone" style="font-size: 1.05rem; font-weight: 700; color: #1e3a8a;"></div>
          <div id="modal-main-phone" style="font-size: 0.9rem; color: #4b5563; margin-top:4px;"></div>
        </div>

        <p id="modal-desc" style="color: #475569; line-height: 1.5; margin-top: 15px;"></p>
        <div style="font-size: 0.95rem; color: var(--text);" id="modal-rank"></div>
      </div>
    </div>

    <script>
      const i18n = {
        ru: {
          logo: "MedPrice РК 🇰🇿", all_cities: "Все города", search: "Найти",
          placeholder: "Кликни на услугу, чтобы увидеть телефоны сотрудников...",
          sidebar: "Выбранные предложения 🛒", total: "Итого чек:",
          add_btn: "+ В корзину", empty: "Добавьте варианты",
          badge_cheap: "Лучшая цена 💸", badge_best: "Топ выбор ⭐",
          address_lbl: "📍 Местонахождение:", staff_lbl: "📞 Контакты сотрудников для записи:",
          doctor_lbl: "Специалист:"
        },
        kk: {
          logo: "MedPrice Қазақстан 🇰🇿", all_cities: "Барлық қалалар", search: "Іздеу",
          placeholder: "Қызметкерлердің нөмірлерін көру үшін басыңыз...",
          sidebar: "Таңдалған ұсыныстар 🛒", total: "Жиынтығы:",
          add_btn: "+ Себетке", empty: "Қызметтерді қосыңыз",
          badge_cheap: "Ең арзан баға 💸", badge_best: "Үздік таңдау ⭐",
          address_lbl: "📍 Мекенжайы:", staff_lbl: "📞 Жазылу үшін қызметкерлердің нөмірлері:",
          doctor_lbl: "Маман:"
        },
        en: {
          logo: "MedPrice RK 🇰🇿", all_cities: "All Cities", search: "Search",
          placeholder: "Click on service to see staff contact numbers...",
          sidebar: "Selected Proposals 🛒", total: "Total Receipt:",
          add_btn: "+ Add", empty: "Add items",
          badge_cheap: "Best Price 💸", badge_best: "Top Choice ⭐",
          address_lbl: "📍 Location:", staff_lbl: "📞 Staff Contacts for Booking:",
          doctor_lbl: "Specialist:"
        }
      };

      const state = { currentLang: 'ru', city: 'all', query: '', compareList: [], allServices: [] };

      function setLanguage(lang) {
        state.currentLang = lang;
        document.querySelectorAll('.lang-btn').forEach(b => {
          b.classList.toggle('active', b.innerText.toLowerCase() === lang);
        });
        
        document.getElementById('lbl-logo').innerText = i18n[lang].logo;
        document.getElementById('opt-all-cities').innerText = i18n[lang].all_cities;
        document.getElementById('search-input').placeholder = i18n[lang].placeholder;
        document.getElementById('search-btn').innerText = i18n[lang].search;
        document.getElementById('lbl-sidebar-title').innerText = i18n[lang].sidebar;
        document.getElementById('lbl-total').innerText = i18n[lang].total;
        
        renderGrid();
        updateCompareSidebar();
      }

      async function fetchServices() {
        let url = `http://127.0.0.1:8000/api/services/search?city=${state.city}`;
        if (state.query) url += `&query=${encodeURIComponent(state.query)}`;
        
        try {
          const res = await fetch(url);
          state.allServices = await res.json();
          renderGrid();
        } catch {
          document.getElementById('grid-content').innerHTML = '<h4 style="color:red;">Запустите бекенд.py!</h4>';
        }
      }

      function renderGrid() {
        const grid = document.getElementById('grid-content');
        const prefix = `[${state.currentLang.toUpperCase()}]`;
        let filtered = state.allServices.filter(s => s.service_name.startsWith(prefix));

        if (!filtered.length) {
          grid.innerHTML = '<h4>Данные не найдены. Сначала запустите Parser.py</h4>';
          return;
        }

        const t = i18n[state.currentLang];
        grid.innerHTML = filtered.map(s => {
          const nameClean = s.service_name.replace(prefix, '');
          return `
            <div class="card">
              <div class="clickable-area" onclick="openModal(${s.id})">
                <div class="badge-container">
                  ${s.is_cheapest ? `<span class="badge-cheap">${t.badge_cheap}</span>` : ''}
                  ${s.is_best_rated ? `<span class="badge-best">${t.badge_best}</span>` : ''}
                </div>
                <h4>${nameClean}</h4>
                <div style="font-weight:700; color:var(--primary);">🏥 ${s.clinic_name}</div>
                
                <div class="location-banner">
                  <span>${t.address_lbl} <strong>${s.city}, ${s.address}</strong></span>
                </div>

                <div class="rating-stars">⭐ ${s.rating} <span style="color:var(--muted); font-weight:normal; font-size:0.8rem;">(${s.reviews_count} отзывов)</span></div>
              </div>
              <div style="text-align:right;">
                <div class="price">${s.price_kzt.toLocaleString()} ₸</div>
                <button class="btn-compare" onclick="event.stopPropagation(); addToCompare(${s.id}, '${nameClean}', ${s.price_kzt}, '${s.clinic_name}')">${t.add_btn}</button>
              </div>
            </div>
          `;
        }).join('');
      }

      window.openModal = function(id) {
        const service = state.allServices.find(x => x.id === id);
        if (!service) return;
        const prefix = `[${state.currentLang.toUpperCase()}]`;
        const t = i18n[state.currentLang];
        
        document.getElementById('modal-title').innerText = service.service_name.replace(prefix, '');
        document.getElementById('modal-clinic-brand').innerText = `🏥 Клиника: ${service.clinic_name} (${service.city})`;
        
        document.getElementById('lbl-staff-title').innerText = t.staff_lbl;
        document.getElementById('modal-staff-phone').innerText = `📱 ${service.staff_phone}`;
        document.getElementById('modal-main-phone').innerText = `☎️ Общий: ${service.phone} | Расписание: ${service.working_hours}`;
        
        document.getElementById('modal-desc').innerText = service.description;
        document.getElementById('modal-rank').innerHTML = `<strong>${t.doctor_lbl}</strong> ${service.doctor_rank}`;
        
        document.getElementById('service-modal').style.display = 'flex';
      }

      window.closeModal = function(e) {
        document.getElementById('service-modal').style.display = 'none';
      }

      window.addToCompare = function(id, name, price, clinic) {
        if (state.compareList.some(x => x.id === id)) return;
        state.compareList.push({ id, name, price, clinic });
        updateCompareSidebar();
      }

      window.removeFromCompare = function(id) {
        state.compareList = state.compareList.filter(x => x.id !== id);
        updateCompareSidebar();
      }

      function updateCompareSidebar() {
        const listEl = document.getElementById('compare-list');
        if (!state.compareList.length) {
          listEl.innerHTML = `<p style="color:var(--muted); text-align:center; padding:20px;">${i18n[state.currentLang].empty}</p>`;
          document.getElementById('total-price').innerText = '0 ₸';
          return;
        }

        listEl.innerHTML = state.compareList.map(x => `
          <div class="compare-item">
            <button class="remove-btn" onclick="removeFromCompare(${x.id})">×</button>
            <div style="font-weight:700;">${x.name}</div>
            <div style="color:var(--primary); font-size:0.85rem;">🏥 ${x.clinic}</div>
            <div style="text-align:right; font-weight:800; color:var(--success);">${x.price.toLocaleString()} ₸</div>
          </div>
        `).join('');

        const total = state.compareList.reduce((sum, i) => sum + i.price, 0);
        document.getElementById('total-price').innerText = `${total.toLocaleString()} ₸`;
      }

      document.getElementById('city-select').addEventListener('change', (e) => { state.city = e.target.value; fetchServices(); });
      document.getElementById('search-btn').addEventListener('click', () => { state.query = document.getElementById('search-input').value.trim(); fetchServices(); });
      
      fetchServices();
      setLanguage('ru');
    </script>
  </body>
</html>"""

class FrontendHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ('/', '/index.html'):
            body = HTML.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()
    def log_message(self, format, *args): return

if __name__ == '__main__':
    print("====================================================")
    print("Интерфейс запущен на: http://127.0.0.1:8001")
    print("====================================================")
    HTTPServer(('127.0.0.1', 8001), FrontendHandler).serve_forever()