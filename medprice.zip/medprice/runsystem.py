import multiprocessing
import re
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import List, Optional
import uvicorn
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# =====================================================================
# 1. СТРУКТУРА ДАННЫХ И ИМИТАЦИЯ БАЗЫ ДАННЫХ
# =====================================================================
# Исходный словарь для нормализации категорий
CATEGORIES_MAP = {
    "оак": "лаборатория",
    "крови": "лаборатория",
    "анализ": "лаборатория",
    "узи": "диагностика",
    "прием": "приём врача",
    "терапевт": "приём врача",
}

# База данных прямо в оперативке. Поля строго согласованы с JS-кодом фронтенда!
DB_NORMALIZED_RECORDS = [
    {
        "id": 1,
        "name": "Общий анализ крови (ОАК)",
        "clinic": "КДЛ Олимп",
        "city": "Алматы",
        "price": 2500,
        "category": "лаборатория",
        "duration": "1 день",
        "url": "https://kdlolymp.kz",
    },
    {
        "id": 2,
        "name": "Общий анализ крови (ОАК)",
        "clinic": "Инвитро",
        "city": "Алматы",
        "price": 2900,
        "category": "лаборатория",
        "duration": "1 день",
        "url": "https://invitro.kz",
    },
]

# =====================================================================
# 2. КОД БЭКЕНДА (FastAPI)
# =====================================================================
backend_app = FastAPI(title="MedPrice API")

# Включаем CORS, чтобы браузер не блокировал запросы к API
backend_app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class RawRecordSchema(BaseModel):
    clinic_id: str
    clinic_name: str
    city: str
    service_name_raw: str
    price_raw: str
    price_kzt: float
    parsed_at: str
    source_url: str


class ParserPayloadSchema(BaseModel):
    raw_records: List[RawRecordSchema]


@backend_app.post("/api/parser/upload")
async def upload_parser_data(payload: ParserPayloadSchema):
    global DB_NORMALIZED_RECORDS
    for record in payload.raw_records:
        # Проверяем, нет ли уже такой клиники с такой услугой
        exists = False
        for existing in DB_NORMALIZED_RECORDS:
            if (
                existing["clinic"] == record.clinic_name
                and existing["name"] == record.service_name_raw
            ):
                existing["price"] = int(record.price_kzt)
                exists = True
                break

        if not exists:
            # Автоматически определяем категорию по ключевым словам
            category = "лаборатория"
            lower_name = record.service_name_raw.lower()
            for key, cat in CATEGORIES_MAP.items():
                if key in lower_name:
                    category = cat
                    break

            DB_NORMALIZED_RECORDS.append(
                {
                    "id": len(DB_NORMALIZED_RECORDS) + 1,
                    "name": record.service_name_raw,
                    "clinic": record.clinic_name,
                    "city": record.city,
                    "price": int(record.price_kzt),
                    "category": category,
                    "duration": "1 день",
                    "url": record.source_url,
                }
            )
    return {"status": "success", "total_records": len(DB_NORMALIZED_RECORDS)}


@backend_app.get("/api/parser/run")
async def run_parser_auto():
    print("[БЭКЕНД] Сигнал с фронтенда получен! Запускаю авто-парсинг сайтов...")

    # Имитируем моментальный сбор свежих данных с сайта Сункар
    import random

    parsed_at = datetime.utcnow().isoformat()
    random_sunkar_price = random.choice([11000, 11500, 12000, 12500])

    fake_parser_records = [
        RawRecordSchema(
            clinic_id="sunkar-777",
            clinic_name="Сункар",
            city="Алматы",
            service_name_raw="УЗИ органов брюшной полости",
            price_raw=f"{random_sunkar_price} KZT",
            price_kzt=float(random_sunkar_price),
            parsed_at=parsed_at,
            source_url="https://sunkar.kz",
        )
    ]

    payload = ParserPayloadSchema(raw_records=fake_parser_records)
    await upload_parser_data(payload)
    return {"status": "success"}


@backend_app.get("/api/services/search")
async def search_services(
    query: Optional[str] = Query(None),
    city: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
):
    results = []
    for record in DB_NORMALIZED_RECORDS:
        # 1. Фильтр по городу (Регистронезависимый)
        if city and record["city"].lower() != city.lower():
            continue
        # 2. Фильтр по категории
        if category and record["category"] != category:
            continue
        # 3. Фильтр по поисковой строке (ищет по названию услуги и по клинике)
        if query:
            q = query.lower()
            if q not in record["name"].lower() and q not in record["clinic"].lower():
                continue

        results.append(record)

    # Всегда сортируем от дешевых к дорогим (Требование ТЗ 3.3)
    results.sort(key=lambda x: x["price"])
    return results


def start_backend():
    uvicorn.run(backend_app, host="127.0.0.1", port=8000, log_level="error")


# =====================================================================
# 3. КОД ФРОНТЕНДА (Твой HTML/JS интерфейс)
# =====================================================================
HTML_CONTENT = """<!DOCTYPE html>
<html lang="ru">
  <head>
    <meta charset="UTF-8" />
    <title>MedPrice — сравнение цен</title>
    <style>
      :root { --bg: #f5f9ff; --surface: #ffffff; --surface-2: #edf5ff; --text: #10243d; --muted: #5f7391; --primary: #1f7aef; --border: #dfe9f7; --shadow: 0 18px 40px rgba(16, 36, 61, 0.08); }
      body { margin: 0; font-family: Arial, sans-serif; color: var(--text); background: var(--bg); }
      .page-shell { max-width: 1240px; margin: 0 auto; padding: 24px 20px; }
      header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 32px; }
      .logo { font-size: 24px; font-weight: 800; color: var(--primary); text-decoration: none; }
      .search-box { background: var(--surface); padding: 20px; border-radius: 16px; box-shadow: var(--shadow); margin-bottom: 32px; display: flex; gap: 12px; }
      .search-input { flex: 1; border: 1px solid var(--border); padding: 14px; border-radius: 10px; font-size: 16px; outline: none; }
      .btn { background: var(--primary); color: #fff; border: none; padding: 14px 28px; border-radius: 10px; font-size: 16px; font-weight: 600; cursor: pointer; }
      .chips { display: flex; gap: 8px; margin-bottom: 24px; }
      .chip { background: var(--surface); border: 1px solid var(--border); padding: 8px 16px; border-radius: 20px; font-size: 14px; cursor: pointer; font-weight: 600; color: var(--muted); }
      .chip.active { background: var(--primary); color: #fff; border-color: var(--primary); }
      .main-grid { display: grid; grid-template-columns: 1fr 340px; gap: 28px; }
      .card { background: var(--surface); border-radius: 14px; border: 1px solid var(--border); padding: 20px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; box-shadow: 0 4px 12px rgba(16,36,61,0.02); }
      .card-title { font-size: 18px; font-weight: 700; margin: 0 0 6px 0; }
      .card-price { font-size: 22px; font-weight: 800; color: var(--text); }
      .status-bar { background: #e0f2fe; color: #0369a1; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; font-weight: 600; display: none;}
    </style>
  </head>
  <body>
    <div class="page-shell">
      <header><a href="#" class="logo">MedPrice</a><div style="background: var(--surface-2); padding: 6px 14px; border-radius: 20px; color: var(--primary); font-weight:600;">Алматы</div></header>
      
      <div class="status-bar" id="status-bar">🔄 Парсер собирает свежие цены с сайтов клиник в реальном времени...</div>

      <div class="search-box">
        <input type="text" class="search-input" id="search-input" placeholder="Введите название услуги или клиники (например: ОАК, УЗИ, Олимп)..." />
        <button class="btn" id="search-btn">Найти</button>
      </div>

      <div class="chips" id="chips">
        <div class="chip active" data-category="">Все категории</div>
        <div class="chip" data-category="лаборатория">Лаборатория</div>
        <div class="chip" data-category="диагностика">Диагностика</div>
        <div class="chip" data-category="приём врача">Приём врача</div>
      </div>

      <div class="main-grid">
        <div id="services-grid" style="width: 100%;"></div>
        <div style="background: var(--surface); padding: 20px; border-radius:16px; border: 1px solid var(--border); height: fit-content;">
          <h3 style="margin-top:0;">Сравнение цен</h3>
          <p style="color:var(--muted); font-size:14px;">Добавьте анализы для сравнения</p>
        </div>
      </div>
    </div>
    
    <script>
      const state = { query: '', category: '' };
      const grid = document.getElementById('services-grid');
      const statusBar = document.getElementById('status-bar');

      // Функция рендеринга карточек
      async function renderServices() {
        let url = `http://127.0.0.1:8000/api/services/search?city=Алматы`;
        if (state.query) url += `&query=${encodeURIComponent(state.query)}`;
        if (state.category) url += `&category=${encodeURIComponent(state.category)}`;
        
        try {
          const res = await fetch(url);
          const services = await res.json();
          
          if(services.length === 0) { 
            grid.innerHTML = '<p style="color:var(--muted);">По вашему запросу ничего не найдено.</p>'; 
            return; 
          }
          
          // Рендерим карточки. Ключи строго совпадают с бэкендом (name, clinic, price)
          grid.innerHTML = services.map(svc => `
            <div class="card">
              <div>
                <h3 class="card-title">${svc.name}</h3>
                <span style="color: var(--muted); font-size:14px;">🏥 ${svc.clinic} | ⏱ ${svc.duration}</span>
              </div>
              <div class="card-price">${svc.price.toLocaleString()} ₸</div>
            </div>
          `).join('');
        } catch { 
          grid.innerHTML = '<p style="color:red;">Ошибка связи с API бэкенда!</p>'; 
        }
      }

      // Функция автозапуска парсера при обновлении страницы (F5)
      async function autoTriggerParser() {
        statusBar.style.display = 'block';
        try {
          await fetch('http://127.0.0.1:8000/api/parser/run');
          statusBar.innerText = '✅ Парсер успешно обновил базу данных!';
          setTimeout(() => statusBar.style.display = 'none', 2500);
        } catch (e) {
          statusBar.innerText = '❌ Ошибка авто-парсинга';
        }
        renderServices();
      }

      // Слушатели событий
      document.getElementById('search-btn').addEventListener('click', () => {
        state.query = document.getElementById('search-input').value.trim();
        renderServices();
      });
      document.getElementById('search-input').addEventListener('keypress', (e) => {
        if(e.key === 'Enter') {
          state.query = document.getElementById('search-input').value.trim();
          renderServices();
        }
      });
      document.getElementById('chips').addEventListener('click', (e) => {
        if(!e.target.classList.contains('chip')) return;
        document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
        e.target.classList.add('active');
        state.category = e.target.dataset.category;
        renderServices();
      });

      // Старт при загрузке
      autoTriggerParser();
    </script>
  </body>
</html>"""


class FrontendHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            body = HTML_CONTENT.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        pass


def start_frontend():
    print("[СИСТЕМА] Фронтенд запущен на http://127.0.0.1:8080")
    HTTPServer(("127.0.0.1", 8080), FrontendHandler).serve_forever()


# =====================================================================
# 4. СТАРТ СИСТЕМЫ ОДНОЙ КНОПКОЙ
# =====================================================================
if __name__ == "__main__":
    print("[СИСТЕМА] Запуск серверов...")
    backend_process = multiprocessing.Process(target=start_backend)
    backend_process.start()

    time.sleep(1)  # Даем бэкенду секунду на запуск

    frontend_process = multiprocessing.Process(target=start_frontend)
    frontend_process.start()

    try:
        backend_process.join()
        frontend_process.join()
    except KeyboardInterrupt:
        print("\n[СИСТЕМА] Экстренное выключение...")
        backend_process.terminate()
        frontend_process.terminate()