import uvicorn
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional

app = FastAPI(title="MedPrice Агрегатор Казахстана (Только Тенге)")

# Разрешаем CORS, чтобы фронтенд без проблем подключался к бэкенду
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class RawRecordSchema(BaseModel):
    clinic_id: str
    clinic_name: str
    city: str
    service_name_raw: str
    price_raw: str
    price_kzt: float
    parsed_at: str
    source_url: str

class ParserPayloadSchema(BaseModel):
    raw_records: List[RawRecordSchema]

DB_RAW_LAYERS = []
DB_NORMALIZED_RECORDS = []

# Стартовая база данных по Казахстану (Тенге)
INIT_DATA = [
    {"clinic": "КДЛ Олимп", "city": "Алматы", "title": "Общий анализ крови (ОАК)", "cat": "лаборатория", "price": 2500.0, "url": "https://kdlolymp.kz"},
    {"clinic": "Инвитро", "city": "Алматы", "title": "Общий анализ крови (ОАК)", "cat": "лаборатория", "price": 2900.0, "url": "https://invitro.kz"},
    {"clinic": "Хеликс", "city": "Астана", "title": "Биохимический анализ крови", "cat": "лаборатория", "price": 6200.0, "url": "https://helix.kz"},
    {"clinic": "МЕДЭЛ", "city": "Караганда", "title": "Приём терапевта первичный", "cat": "приём врача", "price": 7000.0, "url": "https://medel.kz"},
    {"clinic": "МЦК", "city": "Шымкент", "title": "УЗИ органов брюшной полости", "cat": "диагностика", "price": 8500.0, "url": "https://mck.kz"},
]

for i, x in enumerate(INIT_DATA):
    DB_NORMALIZED_RECORDS.append({
        "id": i + 1,
        "clinic_name": x["clinic"],
        "city": x["city"],
        "service_name_norm": x["title"],
        "category": x["cat"],
        "price_kzt": x["price"],
        "url": x["url"],
        "time": "1 день",
    })

@app.post("/api/parser/upload")
async def upload_parser_data(payload: ParserPayloadSchema):
    global DB_NORMALIZED_RECORDS
    start_id = len(DB_NORMALIZED_RECORDS) + 1
    
    for i, record in enumerate(payload.raw_records):
        DB_RAW_LAYERS.append(record.dict())
        
        category = "лаборатория"
        low = record.service_name_raw.lower()
        if any(w in low for w in ["узи", "мрт", "кт", "рентген", "эхо", "экг", "флюорография"]):
            category = "диагностика"
        elif any(w in low for w in ["прием", "консультация", "осмотр"]):
            category = "приём врача"

        DB_NORMALIZED_RECORDS.append({
            "id": start_id + i,
            "clinic_name": record.clinic_name,
            "city": record.city,
            "service_name_norm": record.service_name_raw,
            "category": category,
            "price_kzt": record.price_kzt, # Берем чистый расчет в тенге
            "url": record.source_url,
            "time": "1-2 дня",
        })
    return {"status": "success", "total_in_db": len(DB_NORMALIZED_RECORDS)}

@app.get("/api/services/search")
async def search_services(
    query: Optional[str] = Query(None),
    city: Optional[str] = Query("all")
):
    results = []
    for record in DB_NORMALIZED_RECORDS:
        if city and city != "all" and record["city"].lower() != city.lower():
            continue
        if query:
            q = query.lower()
            if q not in record["service_name_norm"].lower() and q not in record["clinic_name"].lower():
                continue
            
        results.append(record)
        
    # Сортировка строго от дешевых к дорогим (в тенге)
    results.sort(key=lambda x: x["price_kzt"])
    return results

if __name__ == "__main__":
    uvicorn.run("бекенд:app", host="127.0.0.1", port=8000, reload=True)